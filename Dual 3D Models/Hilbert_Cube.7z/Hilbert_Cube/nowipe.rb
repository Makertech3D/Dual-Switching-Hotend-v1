#!/usr/bin/env ruby

filename = 'hilbert_cube1_merged.gcode'

# get rid of toolchange wipe, but leave G54/G54 tool offset and also M106 to make sure the fans stay on
# input = File.read(filename).gsub(/\(\<toolchange\>\).*?(G54|G55).*?\(\<\/toolchange\>\)/m, '\1' + "\nM106 T0\nM106 T1")
input = File.read(filename).gsub(/\(\<toolchange\>\).*?(G54|G55).*?\(\<\/toolchange\>\)/m, '\1')

File.open(filename.gsub('.', '_nowipe.'), 'w') do |output|
  output.puts input
end

